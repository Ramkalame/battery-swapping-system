package com.bss.entity.enums;

public enum UserType {

    SCOOTER,RICKSHAW
}
