package com.bss.entity.enums;

public enum VehicleType {

    E_RICKSHAW,
    E_SCOOTER;
}
