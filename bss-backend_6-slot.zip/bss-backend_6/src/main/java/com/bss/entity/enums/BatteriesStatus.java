package com.bss.entity.enums;

public enum BatteriesStatus {
     EMPTY, CHARGING, FULL_CHARGED;
}
