package com.bss.service;

public interface ArduinoService {

    public String sendCommandToArduino(String command);
}
